//
//  ViewController.swift
//  Mapas
//
//  Created by Raul Guerra Hernandez on 12/30/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var mapa: MKMapView!
    
    private let manejador = CLLocationManager()
    
    var zoomDeltaContador = 2
    let zoomDeltaVector = [0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 0.75, 1, 2, 5]
    
    var inicializador = true
    var puntoActual = CLLocationCoordinate2D()
    var puntoPrevio = CLLocationCoordinate2D()
    var distanciaTotal = 0.0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        manejador.delegate = self
        manejador.desiredAccuracy = kCLLocationAccuracyBest
        manejador.requestWhenInUseAuthorization()
    }
    
    
    
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse{
            manejador.startUpdatingLocation()
            mapa.showsUserLocation = true
        }else{
            manejador.stopUpdatingLocation()
            mapa.showsUserLocation = false
        }
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let latitud = manager.location!.coordinate.latitude
        let longitud = manager.location!.coordinate.longitude
        //let exactitud = manager.location!.horizontalAccuracy
        
        
        let zoomDelta = zoomDeltaVector[zoomDeltaContador]
        let center = CLLocationCoordinate2D(latitude: latitud, longitude: longitud)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: zoomDelta, longitudeDelta: zoomDelta))
        
        self.mapa.setRegion(region, animated: true)
        
        
        // Mostrar el marcador
         puntoActual.latitude = latitud
         puntoActual.longitude = longitud
        
        if inicializador == true {
            
            puntoPrevio = puntoActual
            inicializador = false
            mostrarPunto()
            
        }else{
            
            let from = CLLocation(latitude: puntoPrevio.latitude, longitude: puntoPrevio.longitude)
            let to = CLLocation(latitude: puntoActual.latitude, longitude: puntoActual.longitude)
            let distancia = from.distance(from: to)
            
            //print("Distancia = \(distancia)")
   
            if distancia > 50{
                
                distanciaTotal = distanciaTotal + distancia
                puntoPrevio = puntoActual
                mostrarPunto()
                
            }
        }
    }
    
    
    
    func mostrarPunto(){
        let pin = MKPointAnnotation()
        pin.title = "(\(puntoActual.longitude),\(puntoActual.latitude))"
        pin.subtitle = "dist: \(distanciaTotal) m"
        pin.coordinate = puntoActual
        mapa.addAnnotation(pin)
    }
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error: \(error)")
    }
    
    
    
    class func distance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDistance {
        let from = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let to = CLLocation(latitude: to.latitude, longitude: to.longitude)
        return from.distance(from: to)
    }
    
    
    
    
    // ----- Buttons -----
    
    
    @IBAction func buttonMapNormal() {
        self.mapa.mapType = MKMapType.standard
    }
    
    
    @IBAction func buttonMapSatelite() {
        self.mapa.mapType = MKMapType.satellite
    }
    
    
    @IBAction func buttonMapHibrido() {
        self.mapa.mapType = MKMapType.hybrid
    }
    
    
    @IBAction func buttonZoomIn() {
        if zoomDeltaContador > 0 {
            zoomDeltaContador -= 1
        }
        
    }

  
    @IBAction func buttonZoomOut() {
        if zoomDeltaContador < zoomDeltaVector.count {
            zoomDeltaContador += 1
        }
    }
    
    
}

